package fiap.scj.gerenciamento_filas.to;

public enum StatusSenhaEnum {

	EM_ESPERA, CHAMADO, EM_ATENDIMENTO, FINALIZADO 
	
}
